PCA weighted eye pass v13
=========================

Purpose
-------
Eyes are now treated as first-class, high-weight targets. This pass updates eye
placement using reference head crops and adds a separate eye diagnostic / report.

Important files
---------------
- perfect_cellular_automaton_pil_concept_sheet_v13.py
- perfect_cellular_automaton_pose_polygons_v13.json
- perfect_cellular_automaton_pil_concept_sheet_v13.png
- perfect_cellular_automaton_eye_targets_v13.json
- perfect_cellular_automaton_eye_diagnostic_v13.png
- perfect_cellular_automaton_eye_weighted_fit_report_v13.json
- perfect_cellular_automaton_fit_harness_v13.py
- perfect_cellular_automaton_fit_report_v13.json
- perfect_cellular_automaton_fit_diagnostics_v13.png

Eye scoring
-----------
The dedicated eye report computes black-pixel IoU inside tight eye windows.
Recommended weight in any combined objective: 5x.

Mean v13 eye IoU: 0.793

Rebuild
-------
python /mnt/data/perfect_cellular_automaton_pil_concept_sheet_v13.py

Re-evaluate
-----------
python /mnt/data/perfect_cellular_automaton_fit_harness_v13.py \
  --candidate-script /mnt/data/perfect_cellular_automaton_pil_concept_sheet_v13.py \
  --roi-specs /mnt/data/pca_roi_specs_v13.json \
  --out-json /mnt/data/perfect_cellular_automaton_fit_report_v13.json \
  --out-image /mnt/data/perfect_cellular_automaton_fit_diagnostics_v13.png
